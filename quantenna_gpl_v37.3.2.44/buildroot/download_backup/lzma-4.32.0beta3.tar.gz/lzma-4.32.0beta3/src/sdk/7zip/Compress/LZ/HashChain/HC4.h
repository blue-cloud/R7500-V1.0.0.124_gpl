// HC4.h

#ifndef __HC4_H
#define __HC4_H

#undef HC_NAMESPACE
#define HC_NAMESPACE NHC4

#define HASH_ARRAY_2
#define HASH_ARRAY_3

#include "HC.h"
#include "HCMain.h"

#undef HASH_ARRAY_2
#undef HASH_ARRAY_3

#endif

